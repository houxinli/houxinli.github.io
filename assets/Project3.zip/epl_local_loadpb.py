import tensorflow as tf
import numpy as np
import pandas as pd

np.random.seed(0)
df = pd.read_csv('./1819_ai.csv')
companies = ["B365", "BW", "IW", "PS", "WH", "VC"]
results = ["H","D","A"] 
cols = []
for c in companies:
    for r in results:
        cols.append(c + r)

dataX = df[cols]
dataY = df[["HomeWin","Draw","AwayWin"]]

test_x = np.array(dataX)[300:] # test set 
test_y = np.array(dataY)[300:] 



# parameter ==========================
wkdir = './'
pb_filename = 'epl.pb'

# # load & inference the model ==================

from tensorflow.python.platform import gfile
with tf.Session() as sess:
    # load model from pb file
    with gfile.FastGFile(wkdir+'/'+pb_filename,'rb') as f:
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(f.read())
        sess.graph.as_default()
        g_in = tf.import_graph_def(graph_def)
    # write to tensorboard (check tensorboard for each op names)
    writer = tf.summary.FileWriter(wkdir+'/log/')
    writer.add_graph(sess.graph)
    writer.flush()
    writer.close()
    # print all operation names 
    print('\n===== ouptut operation names =====\n')
    for op in sess.graph.get_operations():
      print(op)
    # inference by the model (op name must comes with :0 to specify the index of its output)
    tensor_output = sess.graph.get_tensor_by_name('import/dense_3/Softmax:0')
    tensor_input = sess.graph.get_tensor_by_name('import/dense_1_input:0')
    predictions = sess.run(tensor_output, {tensor_input: test_x})
    print('\n===== output predicted results =====\n')
    print(predictions)