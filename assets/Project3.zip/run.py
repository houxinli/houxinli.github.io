# -*- coding: utf-8 -*-
# 引入模块部分
import requests
from bs4 import BeautifulSoup
import bs4
import json
import csv

#  定义getHTML()函数
#  目的：获取url链接的网页源码
#  @param $url string
#  @return string
month = {"一月": "-1", "二月": "-2", "三月": "-3", "四月": "-4", "五月": "-5", "六月": "-6", "七月": "-7", "八月": "-8", "九月": "-9", "十月": "-10", "十一月": "-11", "十二月": "-12"}
def getHTML(url):
    # 设定模拟浏览器访问的user_agent
    user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.3"
    # 设定headers中的user_agent
    headers = {'User-Agent': user_agent}
    # 获取目标网页源代码
    r = requests.get(url, headers = headers)
    return r.text 

# 定义目标url
src_url = 'http://china.nba.com/teams/'
# 调用getHTML() 函数
html_text = getHTML(src_url)
# 创建BeautifulSoup对象
soup =  BeautifulSoup(html_text, 'html.parser')


# 获取目标链接地址部分
# 爬取目标链接存储位置声明
team_links = []
# 获取所有a标记中的链接和内容
for box in ["east-box", 'west-box']:
    for a in soup.find(class_ = box).find_all('a'):
        # 获取球队英文名字
        box_name = a.get('href').strip('/')
        # 把爬取球队名字，拼接成目标链接地址
        target_url = "http://china.nba.com/static/data/team/schedule_"+ box_name + ".json"
        # 把link加入之前定义的列表中
        team_links.append(target_url)


# 获取目标数据部分
# 比赛数据存储位置
match_target = []
for link in team_links:
    r = requests.get(link)
    # 获取的r文本 就是json字符串
    json_response = r.content.decode()
    # 将已编码的 JSON 字符串解码为 Python 对象
    dict_json = json.loads(json_response)

    # 处理json数据部分
    for item in dict_json['payload']['monthGroups']:
        # 处理时间部分
        if item['number'] < 13 and item['number'] > 8:
            scheduleYear = '2018'
        else:
            scheduleYear = '2019'
        # 比赛时间
        match_scheduleYM = scheduleYear + "-" + str(item['number'])
        # 处理具体比赛数据部分
        for i in item['games']:
            # for j in i:
            print(i['profile']['dateTimeEt'])
            # 客场方球队名称
            awayTeam = i['awayTeam']['profile']['cityEn'] + " " + i['awayTeam']['profile']['nameEn']
            # 主场球队名称
            homeTeam = i['homeTeam']['profile']['cityEn'] + " " + i['homeTeam']['profile']['nameEn']
            if i['isHome'].lower() == "true":
                # 对方比赛得分
                oppTeamScore = i['oppTeamScore']
                # 我方比赛得分
                teamScore = i['teamScore']
            else:
                # 对方比赛得分
                oppTeamScore = i['teamScore']
                # 我方比赛得分
                teamScore = i['oppTeamScore']
            # 比赛结果
            scoreStatus = True if (teamScore > oppTeamScore) else False
            # 比赛
            #arenaName = i['profile']['arenaName']
            # 组装数据
            match_info = (match_scheduleYM ,homeTeam, teamScore, awayTeam, oppTeamScore, str(scoreStatus))
            # 把组装好的数据写入列表中
            match_target.append(match_info)

# 目标数据保存到csv文件部分
# 定义表头
header_info = ['date', 'hometeam', 'homescore', 'awayteam', 'awayscore', 'result']
# 写入数据
with open('matchs1.csv', 'w') as f:
    f_csv = csv.writer(f)
    # 写表头
    f_csv.writerow(header_info)
    # 写数据
    f_csv.writerows(match_target)