import pandas as pd
import numpy as np
from keras.models import Sequential 
from keras.layers.core import Dense 
from keras.layers import Dense,Activation



df = pd.read_csv('./1819_ai.csv')
# df = pd.read_csv('./1819_raw.csv')

# Div,Date,HomeTeam,AwayTeam,FTHG,FTAG,FTR,HTHG,HTAG,HTR,Referee,
# HS,AS,HST,AST,HF,AF,HC,AC,HY,AY,HR,AR,
# B365H,B365D,B365A,BWH,BWD,BWA,IWH,IWD,IWA,PSH,PSD,PSA,WHH,WHD,WHA,VCH,VCD,VCA,
# Bb1X2,BbMxH,BbAvH,BbMxD,BbAvD,BbMxA,BbAvA,BbOU,BbMx>2.5,BbAv>2.5,BbMx<2.5,BbAv<2.5,
# BbAH,BbAHh,BbMxAHH,BbAvAHH,BbMxAHA,BbAvAHA,PSCH,PSCD,PSCA

# dataX = df.drop(["Div","Date","HomeTeam","AwayTeam","FTHG","FTAG", "FTR", \
# 	"HTHG","HTAG","HTR","Referee","HS","AS","HST","AST","HF","AF","HC",\
# 	"AC","HY","AY","HR","AR"],axis=1)
# dataX = df.drop(["Div","Date","HomeTeam","AwayTeam","FTHG","FTAG", "FTR"\
# 	"HTHG","HTAG","HTR","Referee","HS","AS","HST","AST","HF","AF","HC",\
# 	"AC","HY","AY","HR","AR"],axis=1)
# dataX = df.drop(["Div","Date","HomeTeam","AwayTeam","FTR","Referee","HTR"],axis=1)
# dataX = df.drop(["Div","Date","HomeTeam","AwayTeam",
# "HomeWin","Draw","AwayWin","Referee","HTR"],axis=1)

companies = ["B365", "BW", "IW", "PS", "WH", "VC", "PSC"]
results = ["H","D","A"]	
cols = []
for c in companies:
	for r in results:
		cols.append(c + r)

# for c in companies:
# 	cols.append(c+"H")
# print(cols)

# dataX = df[["B365H", "B365D", "B365A"]]
# dataX = df[["FYHG", "FTAG"]]
# dataX = df[["HS","AS","HST","AST","HF","AF","HC","AC","HY","AY","HR","AR"]]


dataX0 = df[cols]
print(dataX0.head())
dataY = df[["HomeWin","Draw","AwayWin"]]
# dataY = df["FTR"]

dataX = (dataX0-dataX0.mean())/dataX0.std()

print(dataX.head() )
print(dataY.head() )

# train_x = np.array(dataX)[::2] # train set 
# train_y = np.array(dataY)[::2] 
# test_x = np.array(dataX)[1::2] # test set 
# test_y = np.array(dataY)[1::2] 

train_x = np.array(dataX)[:300] # train set 
train_y = np.array(dataY)[:300] 
test_x = np.array(dataX)[300:] # test set 
test_y = np.array(dataY)[300:] 

 
model = Sequential() 
model.add(Dense(60, input_dim=train_x.shape[1], activation='relu')) 
model.add(Dense(30, activation='relu')) 
# model.add(Dense(1, activation='sigmoid')) 
model.add(Dense(3, activation='softmax')) 
# model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy']) 
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy']) 


# model.add(Dense(3))
# model.add(Activation('softmax'))
# model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy']) 

model.summary()

model.fit(train_x, train_y, batch_size = 16, epochs = 100)
print("fit over")
print(model.evaluate(test_x, test_y))

# model.save("epl-model.hdf5") 
# res_y = model.predict(test_x)
# res_y = model.predict(test_x)
# print(res_y)

'''

import tensorflow as tf

np.random.seed(0)

# parameter ==========================
wkdir = './'
pb_filename = 'epl.pb'

# save model to pb ====================
def freeze_session(session, keep_var_names=None, output_names=None, clear_devices=True):
    """
    Freezes the state of a session into a pruned computation graph.
    Creates a new computation graph where variable nodes are replaced by
    constants taking their current value in the session. The new graph will be
    pruned so subgraphs that are not necessary to compute the requested
    outputs are removed.
    @param session The TensorFlow session to be frozen.
    @param keep_var_names A list of variable names that should not be frozen,
                          or None to freeze all the variables in the graph.
    @param output_names Names of the relevant graph outputs.
    @param clear_devices Remove the device directives from the graph for better portability.
    @return The frozen graph definition.
    """
    from tensorflow.python.framework.graph_util import convert_variables_to_constants
    graph = session.graph
    with graph.as_default():
        freeze_var_names = list(set(v.op.name for v in tf.global_variables()).difference(keep_var_names or []))
        output_names = output_names or []
        output_names += [v.op.name for v in tf.global_variables()]
        input_graph_def = graph.as_graph_def()
        if clear_devices:
            for node in input_graph_def.node:
                node.device = ""
        frozen_graph = convert_variables_to_constants(session, input_graph_def,
                                                      output_names, freeze_var_names)
        return frozen_graph

# save keras model as tf pb files ===============
from keras import backend as K
frozen_graph = freeze_session(K.get_session(),
                              output_names=[out.op.name for out in model.outputs])
tf.train.write_graph(frozen_graph, wkdir, pb_filename, as_text=False)

print("All done!")


'''