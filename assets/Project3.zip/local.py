import pandas as pd
import numpy as np
from keras.models import Sequential 
from keras.layers.core import Dense 

df = pd.read_csv('./matches1.csv')

print(df.head())

dataX = df.drop(['hometeam', 'awayteam', 'date', 'result'],axis=1)
dataY = df['result']

print(dataX.head() )
print(dataY.head() )

train_x = np.array(dataX)[::2] # train set 
train_y = np.array(dataY)[::2] 
test_x = np.array(dataX)[1::2] # test set 
test_y = np.array(dataY)[1::2] 
 
model = Sequential() 
model.add(Dense(60, input_dim=train_x.shape[1], activation='relu')) 
model.add(Dense(30, activation='relu')) 
model.add(Dense(1, activation='sigmoid')) 
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy']) 

model.summary()

model.fit(train_x, train_y, batch_size = 16, epochs = 10)
print("fit over")
print(model.evaluate(test_x, test_y))

model.save("nba-model.hdf5") 
