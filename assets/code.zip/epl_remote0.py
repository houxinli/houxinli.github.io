#导入数据
import pandas as pd
import numpy as np
from keras.models import Sequential 
from keras.layers.core import Dense 

# 导入MoXing库
import moxing.tensorflow as mox
import os

data_url = "s3://try0/dataset-epl/"

train_url = './cache/log/'          #训练输出位置。
if not mox.file.exists(data_url):
    raise ValueError('Plese verify your data url!')
if mox.file.exists(train_url):
    mox.file.remove(train_url,recursive=True)
mox.file.make_dirs(train_url)


# 本地创建数据存储文件夹
local_url = './cache/local_data/'
if mox.file.exists(local_url):
    mox.file.remove(local_url,recursive=True)
os.makedirs(local_url)

# 拷贝文件
mox.file.copy_parallel(data_url, local_url)
data_url = local_url
os.listdir(data_url)

df = pd.read_csv( local_url + 'E0.csv')

print(df.head())
# Div,Date,HomeTeam,AwayTeam,FTHG,FTAG,FTR,HTHG,HTAG,HTR,Referee,
# HS,AS,HST,AST,HF,AF,HC,AC,HY,AY,HR,AR,
# B365H,B365D,B365A,BWH,BWD,BWA,IWH,IWD,IWA,PSH,PSD,PSA,WHH,WHD,WHA,VCH,VCD,VCA,Bb1X2,BbMxH,BbAvH,BbMxD,BbAvD,BbMxA,BbAvA,BbOU,BbMx>2.5,BbAv>2.5,BbMx<2.5,BbAv<2.5,BbAH,BbAHh,BbMxAHH,BbAvAHH,BbMxAHA,BbAvAHA,PSCH,PSCD,PSCA
# Div,Date,HomeTeam,AwayTeam,FTHG,FTAG,FTR,HTHG,HTAG,HTR,Referee,HS,AS,HST,AST,HF,AF,HC,AC,HY,AY,HR,AR,B365H,B365D,B365A,BWH,BWD,BWA,IWH,IWD,IWA,PSH,PSD,PSA,WHH,WHD,WHA,VCH,VCD,VCA,Bb1X2,BbMxH,BbAvH,BbMxD,BbAvD,BbMxA,BbAvA,BbOU,BbMx>2.5,BbAv>2.5,BbMx<2.5,BbAv<2.5,BbAH,BbAHh,BbMxAHH,BbAvAHH,BbMxAHA,BbAvAHA,PSCH,PSCD,PSCA

# dataX = df.drop(["Div","Date","HomeTeam","AwayTeam","FTHG","FTAG","FTR",\
# 	"HTHG","HTAG","HTR","Referee","HS","AS","HST","AST","HF","AF","HC",\
# 	"AC","HY","AY","HR","AR"],axis=1)
dataX = df.["B365H","B365D","B365A"]
dataY = df['FTR']

print(dataX.head() )
print(dataY.head() )

train_x = np.array(dataX)[::2] # train set 
train_y = np.array(dataY)[::2] 
test_x = np.array(dataX)[1::2] # test set 
test_y = np.array(dataY)[1::2] 
 
model = Sequential() 
model.add(Dense(60, input_dim=train_x.shape[1], activation='relu')) 
model.add(Dense(30, activation='relu')) 
model.add(Dense(1, activation='sigmoid')) 
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy']) 

model.summary()

model.fit(train_x, train_y, batch_size = 16, epochs = 100)
print("\nfit over! Now evaluate")
print(model.evaluate(test_x, test_y))

# model.save("nba-model.hdf5") 
