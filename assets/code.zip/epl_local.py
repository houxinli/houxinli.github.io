import pandas as pd
import numpy as np
from keras.models import Sequential 
from keras.layers.core import Dense 
from keras.layers import Dense,Activation

df = pd.read_csv('./1819_ai.csv')
# df = pd.read_csv('./1819_raw.csv')

print(df.head())
# Div,Date,HomeTeam,AwayTeam,FTHG,FTAG,FTR,HTHG,HTAG,HTR,Referee,
# HS,AS,HST,AST,HF,AF,HC,AC,HY,AY,HR,AR,
# B365H,B365D,B365A,BWH,BWD,BWA,IWH,IWD,IWA,PSH,PSD,PSA,WHH,WHD,WHA,VCH,VCD,VCA,Bb1X2,BbMxH,BbAvH,BbMxD,BbAvD,BbMxA,BbAvA,BbOU,BbMx>2.5,BbAv>2.5,BbMx<2.5,BbAv<2.5,BbAH,BbAHh,BbMxAHH,BbAvAHH,BbMxAHA,BbAvAHA,PSCH,PSCD,PSCA
# Div,Date,HomeTeam,AwayTeam,FTHG,FTAG,FTR,HTHG,HTAG,HTR,Referee,HS,AS,HST,AST,HF,AF,HC,AC,HY,AY,HR,AR,B365H,B365D,B365A,BWH,BWD,BWA,IWH,IWD,IWA,PSH,PSD,PSA,WHH,WHD,WHA,VCH,VCD,VCA,Bb1X2,BbMxH,BbAvH,BbMxD,BbAvD,BbMxA,BbAvA,BbOU,BbMx>2.5,BbAv>2.5,BbMx<2.5,BbAv<2.5,BbAH,BbAHh,BbMxAHH,BbAvAHH,BbMxAHA,BbAvAHA,PSCH,PSCD,PSCA

# dataX = df.drop(["Div","Date","HomeTeam","AwayTeam","FTHG","FTAG", "FTR", \
# 	"HTHG","HTAG","HTR","Referee","HS","AS","HST","AST","HF","AF","HC",\
# 	"AC","HY","AY","HR","AR"],axis=1)
# dataX = df.drop(["Div","Date","HomeTeam","AwayTeam","FTHG","FTAG", "FTR"\
# 	"HTHG","HTAG","HTR","Referee","HS","AS","HST","AST","HF","AF","HC",\
# 	"AC","HY","AY","HR","AR"],axis=1)
# dataX = df.drop(["Div","Date","HomeTeam","AwayTeam","FTR","Referee","HTR"],axis=1)
# dataX = df.drop(["Div","Date","HomeTeam","AwayTeam","HomeWin","Draw","AwayWin","Referee","HTR"],axis=1)

companies = ["B365", "BW", "IW", "PS", "WH", "VC"]
results = ["H","D","A"]	
cols = []
for c in companies:
	for r in results:
		cols.append(c + r)

# for c in companies:
# 	cols.append(c+"H")
# print(cols)

# dataX = df[["B365H", "B365D", "B365A"]]
# dataX = df[["", "FTAG"]]
dataX = df[["HS","AS","HST","AST","HF","AF","HC","AC","HY","AY","HR","AR"]]

# dataX = df[cols]

dataY = df[["HomeWin","Draw","AwayWin"]]
# dataY = df["FTR"]

print(dataX.head() )
print(dataY.head() )

# train_x = np.array(dataX)[::2] # train set 
# train_y = np.array(dataY)[::2] 
# test_x = np.array(dataX)[1::2] # test set 
# test_y = np.array(dataY)[1::2] 

train_x = np.array(dataX)[:300] # train set 
train_y = np.array(dataY)[:300] 
test_x = np.array(dataX)[300:] # test set 
test_y = np.array(dataY)[300:] 

 
model = Sequential() 
model.add(Dense(60, input_dim=train_x.shape[1], activation='relu')) 
model.add(Dense(30, activation='relu')) 
# model.add(Dense(1, activation='sigmoid')) 
# model.add(Dense(1, activation='softmax')) 
# model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy']) 

model.add(Dense(3))
model.add(Activation('softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy']) 

model.summary()

model.fit(train_x, train_y, batch_size = 16, epochs = 10)
print("fit over")
print(model.evaluate(test_x, test_y))

model.save("epl-model.hdf5") 
# res_y = model.predict(test_x)
res_y = model.predict(test_x)
print(res_y)
